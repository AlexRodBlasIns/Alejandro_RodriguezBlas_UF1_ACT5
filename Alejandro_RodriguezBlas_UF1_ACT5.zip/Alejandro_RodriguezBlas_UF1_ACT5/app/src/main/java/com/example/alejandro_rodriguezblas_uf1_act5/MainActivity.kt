package com.example.alejandro_rodriguezblas_uf1_act5

import android.R.attr.value
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    lateinit var mainActivityButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val myIntent = Intent(this,MainActivity2::class.java)

        mainActivityButton = findViewById(R.id.button)
        mainActivityButton.setOnClickListener{
            startActivity(myIntent)
        }

    }
}